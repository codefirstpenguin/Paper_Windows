#if !defined(AFX_STDAFX_H__7A8025B7_05EC_4F52_B145_E186F2B7416A__INCLUDED_)
#define AFX_STDAFX_H__7A8025B7_05EC_4F52_B145_E186F2B7416A__INCLUDED_

// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#include <afx.h>
#include <afxwin.h>
#include <afxext.h>

//old MFC ISAPI interface, no longer used in WebKnight 3.0 and later
//if you get an error on this line below (in VS2008), see:
//http://blogs.msdn.com/jpsanders/archive/2007/12/10/chttpserver-not-included-in-visual-studio-2008.aspx
//#include <afxisapi.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__7A8025B7_05EC_4F52_B145_E186F2B7416A__INCLUDED)
