/*
    AQTRONIX C++ Library
    Copyright 2009-2010 Parcifal Aertssen

    This file is part of AQTRONIX C++ Library.

    AQTRONIX C++ Library is free software; you can redistribute it
	and/or modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

    AQTRONIX C++ Library is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AQTRONIX C++ Library; if not, write to the Free
    Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
    MA  02111-1307  USA
*/
#include "StdAfx.h"
#include "WebKnightFilter.h"

///////////////////////////////////////////////////////////////////////
// CWebKnightFilter implementation

CWebKnightFilter::CWebKnightFilter():CISAPIFirewall(Settings,logger)
{
	//fix for GetErrorMessage not being able to load string resources
	AfxSetResourceHandle(CProcessHelper::GetCurrentModule());
	//AFX_MANAGE_STATE(AfxGetStaticModuleState( ));

	CSingleLock lock(&Settings.crit, TRUE);
	Initialize(APP_NAME,APP_FULLNAME,"Robots.xml",Settings.Admin.dll.Path);
	lock.Unlock();
}

CWebKnightFilter::~CWebKnightFilter()
{
	CSingleLock lock(&Settings.crit, TRUE);
	Message("AQTRONIX WebKnight unloaded");
	lock.Unlock();
}

BOOL CWebKnightFilter::GetFilterVersion(PHTTP_FILTER_VERSION pVer)
{
	// Call default implementation for initialization
	CISAPIFilter::GetFilterVersion(pVer);
	// Clear the flags set by base class
	pVer->dwFlags &= ~SF_NOTIFY_ORDER_MASK;

	CSingleLock lock(&Settings.crit, TRUE);

	SetFilterVersion(pVer);

	// Load description string
	TCHAR sz[SF_MAX_FILTER_DESC_LEN+1];
	::LoadString(AfxGetResourceHandle(),IDS_FILTER, sz, SF_MAX_FILTER_DESC_LEN);
	_tcscpy(pVer->lpszFilterDesc, sz);

	lock.Unlock();
	return TRUE;
}

void CWebKnightFilter::LoadCache()
{
	CHTTPFirewall::LoadCache();

	BOT_Blocked.SetMaxAge(CTimeSpan(0,Settings.Robots.BotTimeout>1?Settings.Robots.BotTimeout:1,0,0));
	BOT_RequestsLimit.SetMaxAge(CTimeSpan(0,0,Settings.Robots.DenyAggressive.MaxTime>1?Settings.Robots.DenyAggressive.MaxTime:1,0));
}

void CWebKnightFilter::ClearCache()
{
	CHTTPFirewall::ClearCache();
	BOT_Blocked.Clear();
	BOT_RequestsLimit.Clear();
}

CString CWebKnightFilter::GetStatisticsAdditionalCaches()
{
	CString ret("");
	ret += CWebAdmin::GetStatistics("BOT_Blocked",BOT_Blocked);
	ret += CWebAdmin::GetStatistics("BOT_RequestsLimit",BOT_RequestsLimit);
	return ret;
}

CString CWebKnightFilter::GetDynamicFile()
{
	if(Settings.Robots.Dynamic){
		return Settings.Robots.DynamicFile;
	}else{
		return CISAPIFirewall::GetDynamicFile();
	}
}

Action CWebKnightFilter::CustomHeaderScanning(PHTTP_FILTER_CONTEXT pfc, PHTTP_FILTER_PREPROC_HEADERS pHeaders, CString& ip, CURL& RawUrl, CString& ua)
{
	Action action;
	CFileName fn(CURL::Decode(RawUrl.Url));

	//BOTS
	logger.Append(ua.Left(2048));

	bool bRobotFile(false);

	//BOTS
	if(fn.FileNameLCase=="robots.txt"){
		//BOTS - Robots.txt
		if(Settings.Robots.AllowRobotsFile){
			logger.Append("File access 'robots.txt'");
			bRobotFile = true;
		}
		//BOTS - Block All
		if(Settings.Robots.DenyAll){
			BOT_Blocked.Add(ip,ua);
			Alert("Robots not allowed");
		}
		//BOTS - Deny aggressive - start monitoring
		if(Settings.Robots.DenyAggressive.Enabled){
			//add request to cache to start monitoring
			BOT_RequestsLimit.Add(ip,ua);
		}
		//BOTS - Redirect
		if(Settings.Robots.Dynamic){
			CString urlString(RawUrl.RawUrl);
			CStringHelper::Safe_MakeLower(urlString);
			urlString.Replace("robots.txt",Settings.Robots.DynamicFile);
			TCHAR *newUrlString= urlString.GetBuffer(urlString.GetLength());
			pHeaders->SetHeader(pfc, "url", newUrlString);
			//return SF_STATUS_REQ_HANDLED_NOTIFICATION;
		}
	}else{
		//BOTS - Block Aggressive Bots - monitor subsequent requests after robots.txt
		if(Settings.Robots.DenyAggressive.Enabled){
			if(BOT_RequestsLimit.Exists(ip,ua)){
				//add request to cache
				BOT_RequestsLimit.Add(ip,ua);

				//block if number of requests exceeds certain treshold
				if(BOT_RequestsLimit.Count(ip)>Settings.Robots.DenyAggressive.MaxCount){
					BOT_Blocked.Add(ip,ua);
					Alert("Aggressive robot not allowed");
				}
			}
		}
	}

	//BOTS - Block Bad Bots
	if(Settings.Robots.DenyBad){
		if( DenySequences(RawUrl.Url,Settings.Robots.BadBotTraps,"Bad robot fell for trap: '","'") ){
			BOT_Blocked.Add(ip,ua);
		}
	}

	if(!bRobotFile){
		//BOTS - Block if in list
		if(BOT_Blocked.Exists(ip,ua)){
			action.Set(true);
			Alert("Robot not allowed until timeout expires");
		}

		//UA ANOMALIES
		if(Settings.Experimental.UserAgent.Anomalies){

			//TODO: 4.5 - ANOMALIES - Firefox/Chrome/... and other UA anomalies
			if(ua.Find(" Chrome/")!=-1 || ua.Find(" Firefox/")!=-1 || ua.Find(" Edge/")!=-1){
				int anomalies = 0;

				//require these headers
				if(GetServerVariable(pfc,"HTTP_ACCEPT")=="")
					anomalies++;
				if(GetServerVariable(pfc,"HTTP_ACCEPT_LANGUAGE")=="")
					anomalies++;
				if(GetServerVariable(pfc,"HTTP_ACCEPT_ENCODING")=="")
					anomalies++;

				//obvious fake referrers
				CString referrer = GetServerVariable(pfc,"HTTP_REFERER");
				if(referrer=="http://www.google.com" || referrer=="http://www.baidu.com" || referrer=="http://www.google.com/?q=foobar" || referrer=="http://www.whitehouse.gov/")
					anomalies += 10;

				//http/1.0
				CString version = GetServerVariable(pfc,"version");
				if(version=="HTTP/1.0")
					anomalies += 10;

				//unusual http header sequence
				CString rawHeaders = GetServerVariable(pfc,"ALL_RAW");

				//Cookie before Host (is normal in FF)
				//if(Settings.regex_cache.Match(CSignatures::RegexPatternHttpHeaderOrder("Cookie","Host")))
				//	anomalies++;

				if(anomalies>1){
					action.Set(Settings.Experimental.UserAgent.Anomalies);
					Alert("User agent anomalies detected: " + CStringHelper::Safe_IntToAscii(anomalies),Settings.Experimental.UserAgent.Anomalies);
					if(Settings.Experimental.UserAgent.AnomaliesLogRequest)
						LogRequest(pfc);
				}
			}
		}

		//HEADERS: User Agent
		action |= ScanUserAgent(ua,ip);
	}

	return action;
}

bool CWebKnightFilter::CustomSendRawData(PHTTP_FILTER_CONTEXT pfc, PHTTP_FILTER_RAW_DATA pRawData, CString& Response)
{
	/*
	 * Change 'Server' header or remove it.
	 */ 
	bool doflush(false);
	//if we have to do something with the headers
	if(Settings.ResponseMonitor.Headers.Enabled && pfc->pFilterContext!=CONTEXT_SENDING_HEADERS){

		if(ChangeHeader(Response,Settings.ResponseMonitor.Headers.Map)){
			char* p = (char*) pfc->AllocMem(pfc,Response.GetLength()+1,0);
			if(p!=NULL){
				strcpy(p,(LPCTSTR)Response);
				pRawData->pvInData = p;
				pRawData->cbInData = Response.GetLength();
				pRawData->cbInBuffer = Response.GetLength()+1;
				logger.Append("INFO: Changed/removed headers");
			}else{
				logger.Append("WARNING: Error changing/removing headers (could not allocate memory!)");
				doflush = true;
			}
		}else{
			logger.Append(Response); //Response contains error message if false returned
			doflush = true;
		}
	}
	return doflush;
}
