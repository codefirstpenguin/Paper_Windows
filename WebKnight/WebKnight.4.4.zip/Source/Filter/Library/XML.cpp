/*
    AQTRONIX C++ Library
    Copyright 2005-2015 Parcifal Aertssen

    This file is part of AQTRONIX C++ Library.

    AQTRONIX C++ Library is free software; you can redistribute it
	and/or modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

    AQTRONIX C++ Library is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AQTRONIX C++ Library; if not, write to the Free
    Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
    MA  02111-1307  USA
*/
// XML.cpp: implementation of the CXML class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XML.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/* CHANGELOG
 *  2015.07.05 Added AttributeValue() and TagName() (was XMLKeyParameter() of Settings class)
 *  2005.08.26 Class created
 */

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXML::CXML()
{

}

CXML::~CXML()
{

}

CString CXML::Encode(LPCTSTR str)
{
	CString enc(str);
	enc.Replace("&","&amp;");

	enc.Replace("<","&lt;");
	enc.Replace(">","&gt;");
	enc.Replace("'","&apos;");
	enc.Replace("\"","&quot;");

	//https://alexatnet.com/articles/reference-undefined-entity-error-xml-file

	////encode ascii > 127
	//char bufint[34] = "\0";
	//for(char c=255; c>127; c--){
	//	CString entity = "&#";
	//	entity += itoa(c,bufint,10); 
	//	entity+= ";";
	//	enc.Replace(CString(c),entity);
	//}

	return enc;
}

CString CXML::Decode(LPCTSTR str)
{
	CString enc(str);

	////decode ascii > 127
	//char bufint[34] = "\0";
	//for(char c=255; c>127; c--){
	//	CString entity = "&#";
	//	entity += itoa(c,bufint,10); 
	//	entity+= ";";
	//	enc.Replace(entity,CString(c));
	//}

	enc.Replace("&lt;","<");
	enc.Replace("&gt;",">");
	enc.Replace("&apos;","'");
	enc.Replace("&quot;","\"");

	enc.Replace("&amp;","&");
	return enc;
}

CString CXML::AttributeValue(CString tag, CString par)
{
	int pos = tag.Find(par + "=");
	if(pos!=-1){
		CString ret;
		ret = tag.Mid(pos+par.GetLength()+1);
		CString sep(ret.Left(1));
		if(sep=='\'' || sep=='"'){
			ret = ret.Mid(1);
		}else{
			sep = " ";
		}
		pos = ret.Find(sep);
		if(pos!=-1){
			return ret.Left(pos);
		}
	}
	return "";
}

CString CXML::TagName(CString tag)
{
	int pos;
	CString ret(tag);
	pos = tag.Find(' ');
	if(pos!=-1){
		ret = tag.Left(pos);
	}
	ret.TrimLeft('<');
	ret.TrimLeft('/');
	ret.TrimRight('>');
	return ret;
}
