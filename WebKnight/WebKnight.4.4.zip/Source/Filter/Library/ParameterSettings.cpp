/*
    AQTRONIX C++ Library
    Copyright 2015 Parcifal Aertssen

    This file is part of AQTRONIX C++ Library.

    AQTRONIX C++ Library is free software; you can redistribute it
	and/or modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

    AQTRONIX C++ Library is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AQTRONIX C++ Library; if not, write to the Free
    Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
    MA  02111-1307  USA
*/
#include "StdAfx.h"
#include "ParameterSettings.h"

CParameters::CParameters(void)
{
	LoadDefaults();
}

CParameters::~CParameters(void)
{
}

void CParameters::Init()
{
	Query.Init();
	Post.Init();
	Cookie.Init();
	Headers.Init();
}

void CParameters::Clear()
{
	Query.Clear();
	Post.Clear();
	Cookie.Clear();
	Headers.Clear();
}

void CParameters::LoadDefaults()
{
	Query.AllowNotInList = true;
	Query.IgnoreCase = true;
	Post.AllowNotInList = true;
	Post.IgnoreCase = true;
	Cookie.AllowNotInList = true;
	Cookie.IgnoreCase = true;
	Headers.AllowNotInList = true;
	Headers.IgnoreCase = true;

	//VALIDATORS: order has to be from least allowing to most allowing for auto detection

	//Numeric
	AddValidator("Empty","^$");
	AddValidator("Boolean","^[01]$");
	AddValidator("Identity","^[0-9]+$");
	AddValidator("Number","^[+\\-]?[0-9]*$");
	AddValidator("Hexadecimal","^\\h*$");
	AddValidator("Float","^[0-9]+[\\.,][0-9]+$");
	AddValidator("Dot-decimal","^[0-9\\.]*$");
	AddValidator("Range","^\\d+-\\d+$");

	//Datetime
	AddValidator("Time","^\\d\\d:\\d\\d(:\\d\\d(\\.\\d\\d\\d)?)?$");
	AddValidator("Date","^\\d\\d?[/\\-]\\d\\d?[/\\-]\\d\\d\\d?\\d?$");
	AddValidator("ISO Date","^\\d\\d\\d\\d-?\\d\\d-?\\d\\d$");
	AddValidator("Datetime","^\\d\\d\\d\\d-\\d\\d-\\d\\d( |[A-Z])\\d\\d:\\d\\d(:\\d\\d(\\.\\d\\d\\d)?)?$");
	AddValidator("Http Date","^((Sun)|(Mon)|(Tue)|(Wed)|(Thu)|(Fri)|(Sat)), \\d\\d \\c\\c\\c \\d\\d\\d\\d \\d\\d:\\d\\d:\\d\\d GMT$"); //rfc 1123

	//String
	AddValidator("Yes/No","^((Y|y(es)?)|(N|n(o)?))$");
	AddValidator("True/False","^(T|t(rue)?)|(F|f(alse)?)$");
	AddValidator("Order","^((([Aa])|([Dd][Ee]))[Ss][Cc])?$");
	AddValidator("Character","^.?$");
	AddValidator("Alphabetic","^\\c*$");
	AddValidator("Alphanumeric","^\\a*$");
	AddValidator("Alphanumeric List","^((\\a+[,;]\\b?)*\\a+)?$");
	AddValidator("Word","^[a-zA-Z0-9\\-]*$");
	AddValidator("Word List","^(([a-zA-Z0-9\\-]+[,;]\\b?)*[a-zA-Z0-9\\-]+)?$");
	AddValidator("Sentence","^(([a-zA-Z0-9\\-,]+\\b)*[a-zA-Z0-9\\-]+[.\\!\\?]?)?$");
	AddValidator("Filename","^[a-zA-Z0-9_\\.\\-]*$");
	AddValidator("Hostname","^((([a-zA-Z0-9\\-]+\\.)*[a-zA-Z0-9\\-]*)|(\\[([0-9a-fA-F:.])+\\]))$");
	AddValidator("Path","^[a-zA-Z0-9_\\.\\-/]*$");
	AddValidator("Windows Path","^(\\c:)?[a-zA-Z0-9_\\.\\-\\\\]*$");
	AddValidator("E-mail","^([a-zA-Z0-9\\._%\\+\\-]+@([a-zA-Z0-9\\-]+\\.)+[a-zA-Z\\-]+)?$");
	AddValidator("Http Url","^(https?://.+)?$");
	//AddValidator("URL","({[^:/?#]+}:)?(//{[^/?#]*})?{[^?#]*}(?{[^#]*})?(#{.*})?");
	AddValidator("Base64","^([a-zA-Z0-9\\+\\/][a-zA-Z0-9\\+\\/][a-zA-Z0-9\\+\\/][a-zA-Z0-9\\+\\/])*(([a-zA-Z0-9\\+\\/][a-zA-Z0-9\\+\\/]==)|([a-zA-Z0-9\\+\\/][a-zA-Z0-9\\+\\/][a-zA-Z0-9\\+\\/]=))?$");
	AddValidator("Text","^.*$");
}

void CParameters::AddValidator(LPCTSTR Name, LPCTSTR Pattern)
{
	Validation.Patterns.SetAt(Name,Pattern);
	Validation.Order.AddTail(Name);
}

bool CParameters::ApplyConstraints()
{
	CSettings::ApplyConstraints();

	Query.ApplyConstraints();
	Post.ApplyConstraints();
	Cookie.ApplyConstraints();
	Headers.ApplyConstraints();

	return true;
}

bool CParameters::ReadFromFileINI(LPCTSTR fn)
{
	return false;
}

bool CParameters::WriteToFileINI(LPCSTR fn)
{
	return false;
}

bool CParameters::WriteToFileXML(LPCTSTR fn)
{
	CString xml("");

	//xml += "<!DOCTYPE WebApplicationParameters[\r\n";			//start dtd
	//xml += "<!ELEMENT WebApplicationParameters ANY >\r\n";
	//xml += " ]>\r\n";							//end dtd

	xml += "<WebApplicationParameters Version='" + Safe_DoubleToAscii(Version) + "'>\r\n";	//start entity
	xml += "<Web_Application_Parameters App='Document'/>\r\n";
	xml += "<Web_Application_Parameters App='Title'/>\r\n";
	xml += ToXML();
	xml += "</WebApplicationParameters>\r\n";		//end entity
	
	return WriteXMLEntityToFile(fn,xml);
}

bool CParameters::ParseXML(CString &key, CString &val)
{
	//if not a valid key
	if (key=="")
		return false;

	CString name = CXML::Decode(CXML::TagName(key));

	PARSE_XML_CMAPSTRINGTOSTRING(Query,Validators,"Query_Validators")
	else PARSE_XML_CMAPSTRINGTOSTRING(Post,Validators,"Post_Validators")
	else PARSE_XML_CMAPSTRINGTOSTRING(Cookie,Validators,"Cookie_Validators")
	else PARSE_XML_CMAPSTRINGTOSTRING(Headers,Validators,"Headers_Validators")

	else PARSE_XML_CMAPSTRINGTOSTRING(Query,MaxLength,"Query_Max_Length")
	else PARSE_XML_CMAPSTRINGTOSTRING(Post,MaxLength,"Post_Max_Length")
	else PARSE_XML_CMAPSTRINGTOSTRING(Cookie,MaxLength,"Cookie_Max_Length")
	else PARSE_XML_CMAPSTRINGTOSTRING(Headers,MaxLength,"Headers_Max_Length")

	else PARSE_XML_BOOL(Query,AllowNotInList,"Query_Allow_Not_In_List")
	else PARSE_XML_BOOL(Post,AllowNotInList,"Post_Allow_Not_In_List")
	else PARSE_XML_BOOL(Cookie,AllowNotInList,"Cookie_Allow_Not_In_List")
	else PARSE_XML_BOOL(Headers,AllowNotInList,"Headers_Allow_Not_In_List")

	else PARSE_XML_BOOL(Query,IgnoreCase,"Query_Ignore_Case")
	else PARSE_XML_BOOL(Post,IgnoreCase,"Post_Ignore_Case")
	else PARSE_XML_BOOL(Cookie,IgnoreCase,"Cookie_Ignore_Case")
	else PARSE_XML_BOOL(Headers,IgnoreCase,"Headers_Ignore_Case")

	else PARSE_XML_CMAPSTRINGTOSTRING(Validation,Patterns,"Validation_Patterns")
	else PARSE_XML_CSTRINGLIST(Validation,Order,"Validation_Detection")

	else{
		return false;	//not parsed
	}
	return true;
}

CString CParameters::ToXML()
{
	CString xml("");

#define PARAMETERS_GETXML(name, parameter) \
	xml += "<" #name## " App='Separator'/>\r\n"; \
	xml += ConvertMapToXML(#name ## "_Validators",##name.Validators,"Key is the " #parameter## " name and value is the validator to use."); \
	xml += ConvertMapToXML(#name ## "_Max_Length",##name.MaxLength,"Optionally restrict the length of " #parameter## "s. Key is the " #parameter## " name and value is the maximum length of the " #parameter## " value."); \
	xml += ConvertStringToXML(#name##"_Allow_Not_In_List","Option",##name.AllowNotInList?"1":"0","1","Allows unmatched validator " #parameter## "s in the request."); \
	xml += ConvertStringToXML(#name##"_Ignore_Case","Option",##name.IgnoreCase?"1":"0","1","Ignore case of " #parameter## " names when applying validators. When this is disabled, it is recommended to disable Allow Not In List (to prevent bypassing the validators).");

	PARAMETERS_GETXML(Query, parameter)
	PARAMETERS_GETXML(Post, parameter)
	PARAMETERS_GETXML(Cookie, parameter)
	//TODO: 4.5 - HEADERS - remove this
	if(Headers.Cache.Count()>0){
		PARAMETERS_GETXML(Headers, header)
	}

	xml += "<Validation App='Separator'/>\r\n";
	xml += ConvertMapToXML("Validation_Patterns",Validation.Patterns,"The regular expressions used to validate user input.");
	xml += ConvertListToXML("Validation_Detection",Validation.Order,"These are the validators used to automatically detect the parameter type in this exact order. Should be from least allowing to most allowing validator.");

	return xml;
}

CString CParameters::MatchPattern(CString& data)
{
	CString index;
	CString validatorName;
	CString validatorPattern;
	POSITION pos = Validation.Order.GetHeadPosition();
	while(pos!=NULL){
		validatorName = Validation.Order.GetNext(pos);
		if(Validation.Patterns.Lookup(validatorName,validatorPattern)){
			CAtlRegExp<>* regex = Regex.Lookup(validatorPattern);
			if(regex!=NULL){ //NULL = regex syntax error
				CAtlREMatchContext<> mc;
				if(regex->Match(data,&mc)){
					return validatorName;
				}
			}
		}
	}
	return "";
}

bool CParameters::Validate(WebParam& Parameters, CString& name, CString& value)
{
	if(Parameters.IgnoreCase)
		CStringHelper::Safe_MakeLower(name);

	CString validatorName;
	CString validatorPattern;
	if(Parameters.Validators.Lookup(name,validatorName)){
		if(Validation.Patterns.Lookup(validatorName,validatorPattern)){
			CAtlRegExp<>* regex = Regex.Lookup(validatorPattern);
			if(regex!=NULL){ //NULL = regex syntax error
				CAtlREMatchContext<> mc;
				return (regex->Match(value,&mc) == TRUE /* to avoid warning */ && Validate(Parameters,name,value.GetLength()));
			}
		}
	}

	return Validate(Parameters,name,value.GetLength()) && Parameters.AllowNotInList;
}

bool CParameters::Validate(WebParam& Parameters, CString& name, int length)
{
	CString size;
	if(Parameters.MaxLength.Lookup(name,size))
		return !(length>atol(size));

	return true;
}

bool CParameters::HasValidator(WebParam& Parameters, CString name)
{
	LPCTSTR key;
	if(Parameters.Validators.LookupKey(name,key))
		return true;

	CStringHelper::Safe_MakeLower(name);

	if(Parameters.Validators.LookupKey(name,key))
		return true;

	return false;
}