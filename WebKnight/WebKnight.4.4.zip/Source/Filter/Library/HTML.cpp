/*
    AQTRONIX C++ Library
    Copyright 2003-2006 Parcifal Aertssen

    This file is part of AQTRONIX C++ Library.

    AQTRONIX C++ Library is free software; you can redistribute it
	and/or modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

    AQTRONIX C++ Library is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AQTRONIX C++ Library; if not, write to the Free
    Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
    MA  02111-1307  USA
*/
// HTML.cpp: implementation of the CHTML class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HTML.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/* Changelog
 * 2006.04.02: Added HTMLToTags()
 *
 */

CHTML::CHTML()
{

}

CHTML::~CHTML()
{

}

CString CHTML::HTMLToText(CString &html)
{
	int length(html.GetLength());
	bool skip(false);
	CString text("");
	if(length<0)
		length=0;
	for(int i=0;i<length;i++){
		//start skipping htmltag
		if(html[i]=='<'){
			skip = true;
			if(i+2<length && (  (html[i+1]=='b' || html[i+1]=='B') &&
								(html[i+2]=='r' || html[i+2]=='R') &&
								(html[i+3]=='>')					  ) ){
				text += "\r\n";
			}
		}else{
			//copy everything else
			if(!skip){
				text += html[i];
			}
			//stop skipping htmltag
			if(html[i]=='>'){
				skip = false;
			}
		}
	}
	Decode(text);
	return text;
}

CString CHTML::HTMLToTags(CString &html)
{
	int length(html.GetLength());
	bool skip(true);
	CString text("");
	if(length<0)
		length=0;
	for(int i=0;i<length;i++){
		//start skipping htmltag
		if(html[i]=='<'){
			skip = false;
		}
		//copy everything else
		if(!skip){
			text += html[i];
		}
		//stop skipping htmltag
		if(html[i]=='>'){
			skip = true;
		}
	}
	return text;
}

CString& CHTML::Encode(CString& text)
{
	//standard encoded characters
	text.Replace("&","&amp;");
	text.Replace("<","&lt;");
	text.Replace(">","&gt;");
	text.Replace("'","&apos;");
	text.Replace("\"","&quot;");
	
	return text;
}

CString CHTML::Decode(LPCTSTR html)
{
	CString str(html);
	return Decode(str);
}

CString& CHTML::Decode(CString& html)
{
	//standard encoded characters (ascii<127)
	html.Replace("&lt;","<");
	html.Replace("&gt;",">");
	html.Replace("&apos;","'");
	html.Replace("&quot;","\"");
	html.Replace("&frasl;","/");

	//standard encoded characters (ascii>127)
	html.Replace("&ndash;","-");	//en dash
	html.Replace("&mdash;","-");	//em dash
	html.Replace("&nbsp;"," ");		//nonbreaking space
	html.Replace("&iexcl;","�");	//inverted exclamation
	html.Replace("&cent;","�");		//cent sign
	html.Replace("&pound;","�");	//pound sterling
	html.Replace("&curren;","�");	//general currency sign
	html.Replace("&yen;","�");		//yen sign
	html.Replace("&brvbar;","�");	//broken vertical bar
	html.Replace("&brkbar;","�");	//broken vertical bar
	html.Replace("&sect;","�");		//section sign
	html.Replace("&uml;","�");		//umlaut
	html.Replace("&die;","�");		//umlaut
	html.Replace("&copy;","�");		//copyright
	html.Replace("&ordf;","�");		//feminine ordinal
	html.Replace("&laquo;","�");	//left angle quote
	html.Replace("&not;","�");		//not sign
	html.Replace("&shy;","�");		//soft hyphen
	html.Replace("&reg;","�");		//registered trademark
	html.Replace("&macr;","�");		//macron accent
	html.Replace("&hibar;","�");	//macron accent
	html.Replace("&deg;","�");		//degree sign
	html.Replace("&plusmn;","�");	//plus or minus
	html.Replace("&sup2;","�");		//superscript two
	html.Replace("&sup3;","�");		//superscript three
	html.Replace("&acute;","�");	//acute accent
	html.Replace("&micro;","�");	//micro sign
	html.Replace("&para;","�");		//paragraph sign
	html.Replace("&middot;","�");	//middle dot
	html.Replace("&cedil;","�");	//cedilla
	html.Replace("&sup1;","�");		//superscript one
	html.Replace("&ordm;","�");		//masculine ordinal
	html.Replace("&raquo;","�");	//right angle quote
	html.Replace("&frac14;","�");	//one-fourth
	html.Replace("&frac12;","�");	//one-half
	html.Replace("&frac34;","�");	//three-fourths
	html.Replace("&iquest;","�");	//inverted question mark
	html.Replace("&Agrave;","�");	//uppercase A, grave accent
	html.Replace("&Aacute;","�");	//uppercase A, acute accent
	html.Replace("&Acirc;","�");	//uppercase A, circumflex accent
	html.Replace("&Atilde;","�");	//uppercase A, tilde
	html.Replace("&Auml;","�");		//uppercase A, umlaut
	html.Replace("&Aring;","�");	//uppercase A, ring
	html.Replace("&AElig;","�");	//uppercase AE
	html.Replace("&Ccedil;","�");	//uppercase C, cedilla
	html.Replace("&Egrave;","�");	//uppercase E, grave accent
	html.Replace("&Eacute;","�");	//uppercase E, acute accent
	html.Replace("&Ecirc;","�");	//uppercase E, circumflex accent
	html.Replace("&Euml;","�");		//uppercase E, umlaut
	html.Replace("&Igrave;","�");	//uppercase I, grave accent
	html.Replace("&Iacute;","�");	//uppercase I, acute accent
	html.Replace("&Icirc;","�");	//uppercase I, circumflex accent
	html.Replace("&Iuml;","�");		//uppercase I, umlaut
	html.Replace("&ETH;","�");		//uppercase Eth, Icelandic
	html.Replace("&Ntilde;","�");	//uppercase N, tilde
	html.Replace("&Ograve;","�");	//uppercase O, grave accent
	html.Replace("&Oacute;","�");	//uppercase O, acute accent
	html.Replace("&Ocirc;","�");	//uppercase O, circumflex accent
	html.Replace("&Otilde;","�");	//uppercase O, tilde
	html.Replace("&Ouml;","�");		//uppercase O, umlaut
	html.Replace("&times;","�");	//multiplication sign
	html.Replace("&Oslash;","�");	//uppercase O, slash
	html.Replace("&Ugrave;","�");	//uppercase U, grave accent
	html.Replace("&Uacute;","�");	//uppercase U, acute accent
	html.Replace("&Ucirc;","�");	//uppercase U, circumflex accent
	html.Replace("&Uuml;","�");		//uppercase U, umlaut
	html.Replace("&Yacute;","�");	//uppercase Y, acute accent
	html.Replace("&THORN;","�");	//uppercase THORN, Icelandic
	html.Replace("&szlig;","�");	//lowercase sharps, German
	html.Replace("&agrave;","�");	//lowercase a, grave accent
	html.Replace("&aacute;","�");	//lowercase a, acute accent
	html.Replace("&acirc;","�");	//lowercase a, circumflex accent
	html.Replace("&atilde;","�");	//lowercase a, tilde
	html.Replace("&auml;","�");		//lowercase a, umlaut
	html.Replace("&aring;","�");	//lowercase a, ring
	html.Replace("&aelig;","�");	//lowercase ae
	html.Replace("&ccedil;","�");	//lowercase c, cedilla
	html.Replace("&egrave;","�");	//lowercase e, grave accent
	html.Replace("&eacute;","�");	//lowercase e, acute accent
	html.Replace("&ecirc;","�");	//lowercase e, circumflex accent
	html.Replace("&euml;","�");		//lowercase e, umlaut
	html.Replace("&igrave;","�");	//lowercase i, grave accent
	html.Replace("&iacute;","�");	//lowercase i, acute accent
	html.Replace("&icirc;","�");	//lowercase i, circumflex accent
	html.Replace("&iuml;","�");		//lowercase i, umlaut
	html.Replace("&eth;","�");		//lowercase eth, Icelandic
	html.Replace("&ntilde;","�");	//lowercase n, tilde
	html.Replace("&ograve;","�");	//lowercase o, grave accent
	html.Replace("&oacute;","�");	//lowercase o, acute accent
	html.Replace("&ocirc;","�");	//lowercase o, circumflex accent
	html.Replace("&otilde;","�");	//lowercase o, tilde
	html.Replace("&ouml;","�");		//lowercase o, umlaut
	html.Replace("&divide;","�");	//division sign
	html.Replace("&oslash;","�");	//lowercase o, slash
	html.Replace("&ugrave;","�");	//lowercase u, grave accent
	html.Replace("&uacute;","�");	//lowercase u, acute accent
	html.Replace("&ucirc;","�");	//lowercase u, circumflex accent
	html.Replace("&uuml;","�");		//lowercase u, umlaut
	html.Replace("&yacute;","�");	//lowercase y, acute accent
	html.Replace("&thorn;","�");	//lowercase thorn, Icelandic
	html.Replace("&yuml;","�");		//lowercase y, umlaut

	//Decode characters that cannot be represented
	//in pure ascii text
	html.Replace("&lsquo;","�");	//left single quote
	html.Replace("&rsquo;","�");	//right single quote
	html.Replace("&sbquo;","?");	//single low-9 quote
	html.Replace("&ldquo;","?");	//left double quote
	html.Replace("&rdquo;","?");	//right double quote
	html.Replace("&bdquo;","?");	//double low-9 quote
	html.Replace("&dagger;","?");	//dagger
	html.Replace("&Dagger;","?");	//double dagger
	html.Replace("&permil;","?");	//per mill sign
	html.Replace("&lsaquo;","?");	//single left-pointing angle quote
	html.Replace("&rsaquo;","?");	//single right-pointing angle quote
	html.Replace("&spades;","?");	//black spade suit
	html.Replace("&clubs;","?");	//black club suit
	html.Replace("&hearts;","?");	//black heart suit
	html.Replace("&diams;","?");	//black diamond suit
	html.Replace("&oline;","?");	//overline, = spacing overscore
	html.Replace("&larr;","?");		//leftward arrow
	html.Replace("&uarr;","?");		//upward arrow
	html.Replace("&rarr;","?");		//rightward arrow
	html.Replace("&darr;","?");		//downward arrow
	html.Replace("&trade;","(TM)");	//trademark sign

	//remove padding
	while(html.Find("&#0")>-1)
		html.Replace("&#0","&#");

	//normalize hex
	html.Replace("&#X","&#x");
	while(html.Find("&#x0")>-1)
		html.Replace("&#x0","&#x");	

	html.Replace("&#xA","&#xa");
	html.Replace("&#xB","&#xb");
	html.Replace("&#xC","&#xc");
	html.Replace("&#xD","&#xd");
	html.Replace("&#xE","&#xe");
	html.Replace("&#xF","&#xf");

	CString hex;
	for(char h = 'a'; h<'g'; h++){
		hex = "&#x";
		hex += h;
		html.Replace(hex + 'A',hex + 'a');
		html.Replace(hex + 'B',hex + 'b');
		html.Replace(hex + 'C',hex + 'c');
		html.Replace(hex + 'D',hex + 'd');
		html.Replace(hex + 'E',hex + 'e');
		html.Replace(hex + 'F',hex + 'f');
	}

	//Decode &#000; (decimal) and &#x00;(hex) values
	CString dec;
	char bufint[34] = "\0";
	char bufchar[2] = "\0";
	bufchar[1] = '\0';
	for(unsigned char c=255;c>0;c--){
		dec = "&#";
		hex = "&#x";
		dec += itoa((int)c,bufint,10);
		hex += itoa((int)c,bufint,16);
		bufchar[0] = c;
		html.Replace(dec + ';',bufchar);
		html.Replace(hex + ';',bufchar);

		//also without ending ; (see XSS evasion cheat sheet)
		html.Replace(dec,bufchar);
		html.Replace(hex,bufchar);

		//hex with capital A-F
		html.Replace(hex + ';',bufchar);
		html.Replace(hex,bufchar);
	}

	//last
	html.Replace("&amp;","&");

	return html;
}

CString CHTML::FilterTag(CString &HTML, CString TagName)
{
	/*
	 * Removes a tag from the html code
	 */

	//remove a tag: the "<TagName - </TagName>" part
	int taglength = TagName.GetLength()+3;
	int posstart(0); int posstop(-taglength);
	CString html(HTML);
	CString ret;
	html.MakeLower();

	posstart = html.Find("<" + TagName);

	while(posstart!=-1 && posstop!=-1 && posstop<posstart){
		ret += HTML.Mid(posstop+taglength,posstart-posstop-taglength);
		posstop = html.Find("</" + TagName + ">",__max(posstop+taglength,posstart));
		posstart = html.Find("<" + TagName,__max(posstart,posstop+taglength));
	}

	//rest of html
	if(posstop!=-1){
		ret += HTML.Mid(posstop+taglength);
	}
	
	return ret;
}



CString CHTML::ExtractTag(CString &HTML, CString TagName, int Start)
{
	/* 
	 * Extracts a tag at a certain position from first tag in the HTML
	 */
	//extract the "<tagname - </tagname>" part
	CString Tag(HTML);
	Tag.MakeLower();
	//find first tag in html, this is position zero!
	int posstart; posstart = Tag.Find("<" + TagName);
	if(posstart==-1)
		return "";
	//if start is not 0, add Start to posstart
	if(Start!=0){
		posstart+=Start;
		posstart = Tag.Find("<" + TagName,posstart);
		if(posstart==-1)
			return "";
	}
	//stop
	int posstop; posstop = Tag.Find("</" + TagName + ">",posstart);
	if(posstop==-1)
		posstop=HTML.GetLength()-1;
	//if ok, extract...
	if(posstart<posstop){
		Tag = HTML.Mid(posstart,posstop-posstart+TagName.GetLength()+3);
	}else{
		Tag = "";
	}
	return Tag;
}

CString CHTML::ExtractAllTags(CString &HTML, CString TagName)
{
	/*
	 * Extracts all tags from hmtl
	 */
	int pos(0);
	CString extract("");
	CString ret("");
	do{
		extract = ExtractTag(HTML,TagName,pos);
		ret += extract;
		pos += extract.GetLength();
	}while(extract!="");
	
	return ret;
}


